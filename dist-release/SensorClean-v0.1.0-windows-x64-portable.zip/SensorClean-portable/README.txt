SensorClean Pro v0.1.0 (Windows x64)
Copyright (c) 2026 KnobLab

Features:
- Pure-Rust 16-bit CFA Bayer Sensor Dust Inpainting Engine
- Bit-exact DNG 1.6 / ACR XMP generation
- 100% Offline execution without external telemetry

How to run:
- Double-click 'SensorClean.exe' for Desktop GUI.
- Or run 'sensorclean-cli.exe --help' in Command Prompt/PowerShell for batch terminal processing.
