SensorClean Pro v0.1.0 (Pure Native Desktop - Zero WebView2)
=============================================================

This is a 100% pure-Rust standalone native application.
No WebView2, Microsoft Edge, or WebView2Loader.dll is required.

Contents:
- SensorClean.exe: Interactive OpenGL Desktop GUI
- sensorclean-cli.exe: High-performance Batch / CLI Processor

Requirements:
- Windows 10 / 11 (64-bit)
- Standard OpenGL / DirectX display driver

Usage:
1. Double-click SensorClean.exe to run.
2. Click "Open Image..." to load any CFA RAW or standard image.
3. Press [J] to toggle dust overlay visualization.
4. Click "Auto Detect" and "Heal All Spots".
5. Export to Lossless CFA DNG, 16-bit TIFF, PNG, or JPEG.
